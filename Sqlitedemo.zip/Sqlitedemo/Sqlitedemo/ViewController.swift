//
//  ViewController.swift
//  Sqlitedemo
//
//  Created by Mac on 12/10/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    @IBOutlet weak var txtempadd: UITextField!
    
    var obj = dbclass()
    var arr:[Any] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        arr = obj.getdata(query: "select * from tblemp")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

   
    
   
    @IBAction func btninsert(_ sender: Any) {
        
        let query = "insert into tblemp(emp_id,emp_name,emp_add)values('\(txtempid.text!)','\(txtempname.text!)','\(txtempadd.text!)')"
        
        let st = obj.dml(query: query)
        if st == true
        {
            print("Successfull Insert")
        }
        else
        {
            print("Unsuccessfull Insert")
        }
        clear()
        arr = obj.getdata(query: "select * from tblemp")
        tbl.reloadData()
    }
    
    @IBAction func btnupdate(_ sender: Any) {
        let query = "update tblemp set emp_name='\(txtempname.text!)', emp_add='\(txtempadd.text!)' where emp_id='\(txtempid.text!)'"
        
        let st = obj.dml(query: query)
        if st == true
        {
            print("Successfull Update")
        }
        else
        {
            print("Unsuccessfull Update")
        }
        clear()
        arr = obj.getdata(query: "select * from tblemp")
        tbl.reloadData()
    }
    @IBAction func btndelete(_ sender: Any) {
        
        let query = "delete from tblemp where emp_id='\(txtempid.text!)'"
        
        let st = obj.dml(query: query)
        if st == true
        {
            print("Successfull Delete")
        }
        else
        {
            print("Unsuccessfull Delete")
        }
        clear()
        arr = obj.getdata(query: "select * from tblemp")
        tbl.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count+1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell
        if indexPath.row == 0
        {
            cell.lblempid.text = "ID"
            cell.lblempname.text = "Name"
            cell.lblempadd.text = "Address"
        }
        else
        {
           var temp = arr[indexPath.row-1] as! [String]
            
            cell.lblempid.text = temp[0] as! String
            cell.lblempname.text = temp[1] as! String
            cell.lblempadd.text = temp[2] as! String

        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        if indexPath.row != 0
        {
        
            var temp = arr[indexPath.row-1] as! [String]
            let i = temp[0]
        
            let arr1 = obj.getdata(query: "select * from tblemp where emp_id=\(i)")
            temp = arr1[0] as! [String]
        
            txtempid.text = temp[0] as! String
            txtempname.text = temp[1] as! String
            txtempadd.text = temp[2] as! String
        }
    }
    
   func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if indexPath.row != 0
        {
            var temp = arr[indexPath.row-1] as! [String]
            let i = temp[0]
            let query = "delete from tblemp where emp_id='\(i)'"
        
            let st = obj.dml(query: query)
            if st == true
            {
                print("Successfull Delete")
            }
            else
            {
                print("Unsuccessfull Delete")
            }
            clear()
            arr = obj.getdata(query: "select * from tblemp")
            tbl.reloadData()
        }
        else
        {
            
        }
    }
    
    func clear()  {
        txtempid.text = ""
        txtempname.text = ""
        txtempadd.text = ""
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

