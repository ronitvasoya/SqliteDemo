//
//  custcell.swift
//  Sqlitedemo
//
//  Created by Mac on 12/10/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    @IBOutlet weak var lblempid: UILabel!
    @IBOutlet weak var lblempname: UILabel!
    @IBOutlet weak var lblempadd: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
